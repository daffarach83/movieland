<?php require "config.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Add Movie</title>
</head>
<body>
    <header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
     <div class="container">
       <a class="navbar-brand" href="#"><h1>MovieLand</a></h1>
       <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="navbarNavDropdown">
         <ul class="navbar-nav ms-auto">
           <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="#">Home</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="movies.php">Movie List</a>
           </li>
           <li class="nav-item dropdown">
             <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
               More
             </a>
             <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink">
               <li><a class="dropdown-item" href="#">About</a></li>
             </ul>
           </li>
         </ul>
       </div>
     </div>
     <div class="col-4">
        <form method="get">
            <div class="input-group">
                <div class="form-outline">
                    <input type="search" name="search" id="form1" placeholder="Search movie here" class="form-control" />
</div>
        <input type="Submit" class="btn btn-primary" value="Search">
</div>
</form>
   </nav>
</header>
<br>
<br>
<section id="addmovie">
<div class="container">
  <div class="mb-3 row text-center">
    <h1><font face= "clarendon" >Add New Movie</h1></font>
  </div>
    <div class="wrapper">
        <?php
        if(isset($_POST['submit'])) {
            if (isset($_FILES['poster'])) {
                $title = $_POST['title'];
                $genre = $_POST['genre'];
                $production = $_POST['production'];
                $rdate = $_POST['rdate'];
                $deskripsi = $_POST['deskripsi'];
                $ytlink = $_POST['ytlink'];
                $file_tmp = $_FILES['poster']['tmp_name'];
                $type = pathinfo($file_tmp, PATHINFO_EXTENSION);
                $data = file_get_contents($file_tmp);
                $poster = 'data:image/' . $type . ';base64,' . base64_encode($data);

                $script = "INSERT INTO movies SET title='$title', genre='$genre', production='$production', rdate='$rdate',
                deskripsi='$deskripsi', ytlink='$ytlink', poster='$poster'";
                $query = mysqli_query($conn, $script);
                if ($query) {
                    header("location:movies.php");
                } else {
                    echo "gagal mengupload data";
                }
            }
        }
    ?>
    <br>
    </div>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label> Title </label>
            <input type="text" class="form-control" name="title">
        </div>
        <div class="form-group">
            <label> Poster </label>
            <input type="file" class="form-control" name="poster">
        </div>
        <div class="form-group">
            <label> Genre </label>
            <select name="genre" class="form-control">
            <option>-------------------------------------------------Choose Genre-------------------------------------------------</option>
	        <option value="Horror/thriller">Horror/thriller</option>
          <option value="Action">Action</option>
          <option value="Action">Animation</option>
	        <option value="Romance">Romance</option>
	        <option value="Mystery">Mystery</option>
	        <option value="Fantasy">Fantasy</option>
</select>
        <div class="form-group">
            <label> Production House (PH) </label>
            <input type="text" class="form-control" name="production">
        </div>
        <div class="form-group">
            <label> Release Date </label>
            <input type="date" class="form-control w-50" id="rdate" name="rdate">
        </div>
        <div class="form-group">
					<label>  Description </label>
					<textarea name="deskripsi" class="form-control" cols="30" rows="10"></textarea> 
				</div>
        <div class="form-group">
            <label> Trailer Link </label>
            <input type="url" class="form-control" name="ytlink">
        </div>
            <input type="submit" class="btn btn-primary" name="submit" value="Upload">
            <a href="movies.php" type="submit" class="btn btn-primary"> Cancel </a>
    </form>
    <br><br><br>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" 
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" 
        integrity="sha384-06E9RHvbIyZFJoft+2mJbHaEWldlvI9I0Yy5n3zV9zzTtmI3UksdRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" 
        integrity="sha384-wfSDF2E50Y2D1uldj003uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCEx130g8ifwB6" crossorigin="anonymous"></script>
</body>
</html>