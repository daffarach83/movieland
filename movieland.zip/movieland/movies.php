<?php require "config.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Movies</title>
</head>
<body>
<header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
     <div class="container">
       <a class="navbar-brand" href="#"><h1>MovieLand</a></h1><br>
       <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="navbarNavDropdown">
         <ul class="navbar-nav ms-auto">
           <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="index.php">Home</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="movies.php">Movie List</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="create.php">Add Movie</a>
           </li>
         </ul>
       </div>
     </div>
     <div class="col-4">
        <form method="get">
            <div class="input-group">
                <div class="form-outline">
                    <input type="search" name="search" id="form1" placeholder="Search movie here" class="form-control" />
</div>
        <input type="Submit" class="btn btn-primary" value="Search">
</div>
</form>
   </nav>
</header>
<br>
    <ul><a href="create.php" type="submit" class="btn btn-primary">[+] Add New Movie</a></ul>

    <div class="wrapper">
        <div class="row">
            <?php
                $batas = 5;
                $halaman = @$_GET['halaman'];
                if(empty($halaman)){
                    $posisi = 0;
                    $halaman = 1;
                }
                else{
                    $posisi = ($halaman-1) * $batas;
                }
                if(isset($_GET['search'])){
                    $search = $_GET['search'];
                    $sql="SELECT * from movies WHERE title LIKE '%$search' order by id Desc limit $posisi, $batas";
                }else{
                    $sql="SELECT * from movies order by id Desc limit $posisi, $batas";
                }

                $hasil=mysqli_query($conn, $sql);
                while ($data = mysqli_fetch_array($hasil)){
            ?>
                <div class="col-md-3 produk">
                    <a href="movie_detail.php?id=<?= $data['id'] ?>">
                    <img src="<?= $data['poster'] ?>" width="100%" alt="">
                    <h4><?=$data["title"] ?></h4>
                    <p class="genre-movie"> <?= $data['genre'] ?></p>
                    <p class="ph-movie">Production House: <?=$data['production']?></p>
                    </a>
                </div>
            <?php }
            ?>
        </div>
        <?php
        if(isset($_GET['search'])){
            $search = $_GET['search'];
            $query2 = "SELECT * from movies WHERE title LIKE '%$search' order by id Desc";
        }else{
            $query2 = "SELECT * from movies order by id Desc";
        }
        $result2 = mysqli_query($conn, $query2);
        $jmldata = mysqli_num_rows($result2);
        $jmlhalaman = ceil($jmldata/$batas);
        ?>
        <br>
        <ul class="pagination">
            <?php
            for($i=1;$i<=$jmlhalaman;$i++){
                if ($i !=$halaman){
                    if(isset($_GET['search'])){
                        $search = $_GET['search'];
                        echo "<li class='page-item'><a class='page-link' href='read.php?halaman=$i&search=$search'>$i</a></li>";
                    }else{
                        echo "</li class='page-item'><a class='page-link' href='read.php?halaman=$i'>$i</a></li>";
                    }

                }else{
                    echo "<li class='page-item active'><a class='page-link' href='#'>$i</a></li>";
                }
            }
            ?>
        </ul>
        </div>
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" 
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" 
        integrity="sha384-06E9RHvbIyZFJoft+2mJbHaEWldlvI9I0Yy5n3zV9zzTtmI3UksdRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" 
        integrity="sha384-wfSDF2E50Y2D1uldj003uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCEx130g8ifwB6" crossorigin="anonymous"></script>
</body>
</html>