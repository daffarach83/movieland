<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 
    <title>Genre</title>
  </head>
</header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
     <div class="container">
       <a class="navbar-brand" href="#"><h1>MovieLand</a></h1><br>
       <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="navbarNavDropdown">
         <ul class="navbar-nav ms-auto">
           <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="index.php">Home</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="movies.php">Movie List</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="create.php">Add Movie</a>
           </li>
         </ul>
       </div>
     </div>
     <div class="col-4">
        <form method="get">
            <div class="input-group">
                <div class="form-outline">
                    <input type="search" name="search" id="form1" placeholder="Search movie here" class="form-control" />
</div>
        <input type="Submit" class="btn btn-primary" value="Search">
</div>
</form>
   </nav>
</header>
  <body background="img\genre.jpg" >
    <!-- Optional JavaScript; choose one of the two! -->
 
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
 
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
    <br>
    <br>
    <center><font face="Garamond" color="white" size="20">GENRES OVERVIEW</font></center>
    <br>
<!--card-->
<section id="card">
  <div class="container">
    <div class="row row-cols-1 row-cols-md-3 g-4">
      <div class="col mb-5">
        <div class="card h-100">
          <img src="img\horror1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Horror/Thriller</h5>
            <p class="card-text">a film genre that seeks to elicit fear or disgust in its audience for entertainment purposes.[2]

Horror films often explore dark subject matter and may deal with transgressive topics or themes. Broad elements include monsters, apocalyptic events, and religious or folk beliefs. 
Cinematic techniques used in horror films have been shown to provoke psychological reactions in an audience.</p>
          </div>
          <div class="card-footer">
            <small class="text-muted">rate 19+</small>
          </div>
        </div>
      </div>
      <div class="col mb-5">
        <div class="card h-100 text-center">
          <img src="img\action1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Action</h5>
            <p class="card-text">a film genre in which the protagonist is thrust into a series of events that typically involve violence and physical feats. The genre tends to feature a mostly resourceful hero struggling against incredible odds, which include life-threatening situations, a dangerous villain, or a pursuit which usually concludes in victory for the hero.</p>
          </div>
          <div class="card-footer">
            <small class="text-muted">rate 13+</small>
          </div>
        </div>
      </div>
      <div class="col mb-5">
        <div class="card h-100 text-end">
          <img src="img\animation1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Animation</h5>
            <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content.
              This card has even longer content than the first to show that equal height action.</p>
          </div>
          <div class="card-footer">
            <small class="text-muted">Family Friendly</small>
          </div>
        </div>
      </div>
      <div class="col mb-5">
        <div class="card h-100 text-end">
          <img src="img\romance1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Romance</h5>
            <p class="card-text">movies involve romantic love stories recorded in visual media for broadcast in theatres or on television that focus on passion, emotion, and the affectionate romantic involvement of the main characters. Typically their journey through dating, courtship or marriage is featured. These films make the search for romantic love the main plot focus.</p>
          </div>
          <div class="card-footer">
            <small class="text-muted">rate 15+</small>
          </div>
        </div>
      </div>
      <div class="col mb-5">
        <div class="card h-100 text-end">
          <img src="img\mystery1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Mystery</h5>
            <p class="card-text">a genre of film that revolves around the solution of a problem or a crime. It focuses on the efforts of the detective, private investigator or amateur sleuth to solve the mysterious circumstances of an issue by means of clues, investigation, and clever deduction.</p>
          </div>
          <div class="card-footer">
            <small class="text-muted">rate 13+</small>
          </div>
        </div>
      </div>
      <div class="col mb-5">
        <div class="card h-100 text-end">
          <img src="img\fantasy1.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Fantasy</h5>
            <p class="card-text">belong to the fantasy genre with fantastic themes, usually magic, supernatural events, mythology, folklore, or exotic fantasy worlds. The genre is considered a form of speculative fiction alongside science fiction films and horror films, although the genres do overlap.</p>
          </div>
          <div class="card-footer">
            <small class="text-muted">family friendly</small>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<center><a href="movies.php" type="submit" class="btn btn-primary">Get movie recommendation</a></center>
<br>
<br>
</html>
<!--End card-->