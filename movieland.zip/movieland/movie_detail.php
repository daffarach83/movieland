<?php
require "config.php";
	if($_GET['id'] != null){
		$id = $_GET['id']; 
		$script = "SELECT * FROM movies WHERE id=$id"; 
		$query = mysqli_query($conn, $script);
		$data = mysqli_fetch_array($query);
	}else{
		header("location: movies.php");
	}

	$query2 = null;

	if(isset($_POST['delete'])) {
		$script2 = "DELETE FROM movies WHERE id = $id"; 
		$query2 = mysqli_query($conn, $script2);
	}

	if($query2 != null){
		header("location:movies.php");
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Movie</title>
</head>
<body>
<header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
     <div class="container">
       <a class="navbar-brand" href="#"><h1>MovieLand</a></h1>
       <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse" id="navbarNavDropdown">
         <ul class="navbar-nav ms-auto">
           <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="#">Home</a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="movies.php">Movie List</a>
           </li>
           <li class="nav-item dropdown">
             <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
               More
             </a>
             <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink">
               <li><a class="dropdown-item" href="#">About</a></li>
             </ul>
           </li>
         </ul>
       </div>
     </div>
     <div class="col-4">
        <form method="get">
            <div class="input-group">
                <div class="form-outline">
                    <input type="search" name="search" id="form1" placeholder="Search movie here" class="form-control" />
</div>
        <input type="Submit" class="btn btn-primary" value="Search">
</div>
</form>
   </nav>
</header>
<br>
<ul>
		<a href="movies.php" type="submit" class="btn btn-primary">Back</a>
	</ul>
		<div class="wrapper"> 
			<div class="row"> 
				<div class="col-7"> 
					<img src="<?= $data['poster'] ?>" width="90%" alt=""> 
				</div> 
				<div class="col-4"> 
					<div class="box-detail-produk">
						<h2>Movie Detail</h2> <h3><?= $data['title'] ?></h3> 
						<h5>Genre: <?= $data['genre']?></h5>
						<p> Production House : <?= $data['production'] ?></p> 
					</div> 
					<div class="box-detail-produk">
						<h2>Movie Trailer</h2> 
						<h3><?= $data['title'] ?></h3> 
						<a href="<?= $data['ytlink'] ?>" class="btn btn-success">Watch Trailer</a> 
					</div> 
					<div class="box-detail-produk">
					<h2>Edit</h2> 
					<form method="post">
						<a href="edit.php?id=<?= $data['id'] ?>" class="btn btn-warning">Update movie</a>
						<input type="submit" name="delete" value="Delete Movie" class="btn btn-danger"> 
					</form> 
				</div>
				<div class="col-md-12">
					<div class="box-detail-produk">
						<h2>Movie Description</h2>
						<p><?= $data['deskripsi'] ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" 
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" 
        integrity="sha384-06E9RHvbIyZFJoft+2mJbHaEWldlvI9I0Yy5n3zV9zzTtmI3UksdRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" 
        integrity="sha384-wfSDF2E50Y2D1uldj003uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCEx130g8ifwB6" crossorigin="anonymous"></script>
</body>
</html>